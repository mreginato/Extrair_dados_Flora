library(devtools)
library(monographaR)
library(shiny)

setwd("C:/key")

#################################
### Install monographaR
#################################

### last version from github

#install_github("mreginato/monographaR")


#################################
### Import data
#################################

read.csv("Pleiochiton_dat.csv") -> dat

#################################
### Text labels
#################################

interactiveKeyLabels(taxon="species", language="english") -> txt.labels
txt.labels


#################################
### Generate key
#################################

interactiveKey(dat, txt.labels=txt.labels, poly.sep="/", state.sep=" = ", taxa.in.italics=TRUE)

runApp()



#################################
### Modify Text labels
#################################

interactiveKeyLabels(taxon="species", language="portuguese") -> txt.labels
txt.labels


### to modify it

write.table(txt.labels, "txt_labels.txt")

## open the file and modify it as you wish

### Import it

read.table("txt_labels.txt") -> txt.labels


#################################
### Generate key
#################################

interactiveKey(dat, txt.labels=txt.labels, poly.sep="/", state.sep=" = ", taxa.in.italics=TRUE)

runApp()
