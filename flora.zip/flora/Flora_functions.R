getFloraTaxa <- function(family=NULL, genus=NULL, data=NULL, check.correct=T) {
  data -> taxons
  taxons[which(taxons$family == family),] -> taxons
  taxons[which(taxons$taxonomicStatus == "NOME_ACEITO"),] -> taxons
  if (check.correct) {
    taxons[which(taxons$nomenclaturalStatus == "NOME_CORRETO"),] -> taxons
  }
  taxons[which(taxons$taxonRank == "ESPECIE"),] -> taxons
  taxons[which(taxons$genus == genus),] -> taxa
  return(taxa)
}

buildMatrix <- function(descriptions=NULL) {
  descriptions[[1]] -> d0
  trimws(unlist(strsplit(d0, ".", fixed=T))) -> d0
  unlist(lapply(strsplit(d0, ":"), "[", 1)) -> chars.main
  unlist(lapply(strsplit(d0, ";"), length)) -> n
  rep(chars.main, n) -> chars.all
  
  dat <- matrix(ncol=length(chars.all), nrow=length(descriptions))
  colnames(dat) <- chars.all
  rownames(dat) <- names(descriptions)
  
  for (i in 1:length(descriptions)) {
    descriptions[[i]] -> d0
    trimws(unlist(strsplit(d0, ". ", fixed=T))) -> d0
    d0[1:length(chars.main)] -> d0
    unlist(lapply(strsplit(d0, ": "), "[", 2)) -> d0
    trimws(unlist(strsplit(d0, ";"))) -> dat[i,]
  }
  return(dat)
}

extractDescriptions <- function(taxa=NULL) {
  ## Se der erro, mudar o timeout no javascript
  
  ini.m = "Description with controlled"
  final.m1 = "Free description"
  final.m2 = "Commentaries"
  final.m3 = "Vouchers"
  final.m4 = "Reference"
  
  vector("list", length = nrow(taxa)) -> descriptions
  names(descriptions) <- taxa$scientificName
  vector() -> failures
  
  for (i in 1:nrow(taxa)) {
    try(unlink("temp.pdf"))
    taxa$references[i] -> u0
    paste(u0, "&action=print", sep="") -> u0
    call <- paste("phantomjs save_page.js", u0, "temp.pdf")
    system(call)
    pdf_text("temp.pdf") -> txt
    unlist(strsplit(as.character(txt[[1]]), "\n", fixed=T)) -> d0
    grep(ini.m, d0)+1 -> i0
    if (length(i0) > 0) {
      grep(final.m1, d0)-1 -> i1
      if (length(i1) == 0) {
        grep(final.m2, d0)-1 -> i1
      }
      if (length(i1) == 0) {
        grep(final.m3, d0)[1]-1 -> i1
        na.omit(i1) -> i1
      }
      if (length(i1) == 0) {
        grep(final.m4, d0)[1]-1 -> i1
        na.omit(i1) -> i1
      }
      d0[i0:i1] -> d0
      gsub("\r", "", d0, fixed=T) -> d0
      trimws(d0) -> d0
      paste(d0, collapse = " ") -> d0
      d0 -> descriptions[[i]]
    } else {
      c(failures, taxa$scientificName[i]) -> failures
    }
    cat("\r",i)
  }
  if (length(failures) > 0) {
    list(descriptions, failures) -> descriptions
  }
  return(descriptions)
}

