library(pdftools)
library(data.table)

####################################################
### WD mudar esse endereço
####################################################

setwd("C:/flora")

####################################################
### Import functions
####################################################

source("Flora_functions.R")

####################################################
### Import Flora Data
####################################################

fread("taxon.txt", stringsAsFactors = F) -> flora
as.data.frame(flora, stringsAsFactors=F) -> flora

####################################################
### Extract taxa
####################################################

### Mudar para o taxon de interesse

family = "Bromeliaceae"
genus = "Neoregelia"

getFloraTaxa(family, genus, data=flora, check.correct = F) -> taxa
nrow(taxa)
head(taxa)

####################################################
### Load pages
####################################################

## Se der erro, mudar o timeout no javascript

extractDescriptions(taxa) -> descriptions
descriptions

sink(paste(genus, "descriptions.txt", sep="_"))
descriptions
sink()

save.image("work.Rdata")

####################################################
### Build matrix
####################################################

buildMatrix(descriptions) -> mat

write.csv(mat, paste(genus, "_matrix.csv", sep=""))



